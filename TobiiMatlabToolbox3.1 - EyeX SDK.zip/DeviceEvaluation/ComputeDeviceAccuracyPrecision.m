%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Compute accuracy and precision on the subjects' dataset.

clear, close all, clc

%% MANAGE DIRECTORIES
addpath functions
addpath ../tobii_matlab
load_dir='DATA/';

subject_list=dir(load_dir); subject_list(1:2)=[];

%% GLOBAL VARIABLES
global ANG_ERROR_L
global ANG_ERROR_R

global n
n=1;

trial_num=4;
for s=1:length(subject_list)
    
    subject=subject_list(s).name;
    display(['COMPUTING SUBJECT: ' subject])
    
    for trial=1:trial_num
        
        display(['TRIAL: ' num2str(trial)])
        
        [ERR_LB(trial,s,:) ERR_RB(trial,s,:) PREC_LB(trial,s,:) PREC_RB(trial,s,:)] = ComputeAccuracyPrecision(...
            [load_dir subject '/DATA_CB' num2str(trial)],[load_dir subject '/DATA_CB' num2str(trial)],...
            [load_dir subject '/DATA_TB' num2str(trial)],[load_dir subject '/DATA_TB' num2str(trial)]);
        
        [ERR_LM(trial,s,:) ERR_RM(trial,s,:) PREC_LM(trial,s,:) PREC_RM(trial,s,:)] = ComputeAccuracyPrecision(...
            [load_dir subject '/DATA_CL' num2str(trial)],[load_dir subject '/DATA_CR' num2str(trial)],...
            [load_dir subject '/DATA_TL' num2str(trial)],[load_dir subject '/DATA_TR' num2str(trial)]);
        
    end
end

%% DATA SAVE
save DeviceAccuracyPrecision

%% PLOT ACCURACY
TEST_TYPE='accu';
PLOT_AccuracyPrecision

%% PLOT PRECISION
TEST_TYPE='prec';
PLOT_AccuracyPrecision


