%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Aquiring of a single subject.

clear, close all, clc

%% MATLAB PATH
addpath ../tobii_matlab

%% CHECK SOFTWARE
chk = chk_software('../../matlab_server');

%% SCREENSIZE
% SET SCREEN DIAGONAL IN INCHES
screen_size=mm2inch(15.6); %mm
% SET SCREEN ASPECT RATION
scree_ratio=16/9; screen_diag=sqrt(16^2+9^2);

H=screen_size*9/screen_diag;
W=screen_size*16/screen_diag;
pix_mm=W/1920;

subject_distance=500;
pix_deg=atand(pix_mm/subject_distance);

%% CREATE DIRECTORIES
save_dir='DATA\';               %be careful putting the slash at the end

def_dir=0;
while def_dir==0
    prompt='INSERT SUBJECT NAME AND PRESS ENTER: ';
    subject=input( prompt ,'s');
    
    if isempty(dir(save_dir))
        mkdir(save_dir)
    end
    
    if isempty(dir([save_dir subject]))
        mkdir([save_dir subject])
        def_dir=1;
    else
        display(['THE DIRECTORY ALREADY EXISTS, DO YOU WANT TO CHANGE NAME? (y/n)'])
        FlushEvents;
        pause(0.2)
        [dumb exits] = KbWait;
    
        if find(exits)==78
            def_dir=1;
        end
    end
    
    if isempty(dir([save_dir subject '/traj'])) && def_dir==1
        mkdir([save_dir subject '/traj'])
    end
    
end

subject=[subject '\'];

%% TOBII SETUP
% START SERVER AND OPEN UDP PORT
server_path=fullfile(pwd,'../matlab_server/'); %if the Matlab server is in a different folder wrt the original one, write here the FULL PATH, e.g. C:\TobiiMatlabToolbox\matlab_server\
tobii  =  tobii_connect(server_path);
% INITIALIZE EYE TRACKER
[msg DATA tobii] =  tobii_command(tobii,'init');

%% PSYCHOTOOLBOX SETUP
% Skip sync test
Screen('Preference', 'SkipSyncTests', 1);
% Init PsychoToolbox
PsychDefaultSetup(2);
% Get the screen numbers
screens  =  Screen('Screens');
% Draw to the external screen if avaliable
screenNumber  =  max(screens);
% Define colors
white = WhiteIndex(screenNumber);
black = BlackIndex(screenNumber);
grey = (WhiteIndex(screenNumber)+BlackIndex(screenNumber))/2;

% Open an on screen window
% [window, windowRect] = Screen('OpenWindow',screenNumber, grey); % open screen
[window, windowRect]  =  PsychImaging('OpenWindow', screenNumber, grey);


%% EXPERIMENT SETUP
% CALIBRATION TARGET
MX=.8; MN=.2; MD=.5; MDL=0.35; MDH=0.65;

TargetCalib=[MD, MX, MN, MN, MX, MD, MN, MX, MD, MDL, MDL, MDH, MDH;...
             MD, MX, MX, MN, MN, MN, MD, MD, MX, MDL, MDH, MDL, MDH];

% TEST TARGET
MN=.25; MD=.5; MDL=0.375; MDH=0.35;

TargetTest=[MDH MD  MD  1-MDH MN  1-MN  MN  1-MN  MDL 1-MDL 1-MDL MDL;...
            MD  MDH 1-MDH MD  1-MDL MDL MDL 1-MDL MN  1-MN  MN  1-MN];

ExperimentType=['CB'; 'CL'; 'CR'; 'TB'; 'TL'; 'TR']; % Binocular Left Right TestBinocular TestLeft TestRight

rep_num=4; % number of test repetitions per subject

%% RUN EXPERIMENT
% POSITION GUIDE
[msg DATA tobii] =  tobii_command(tobii,'start',[save_dir subject 'traj\']);
PositionGuide(tobii,window,windowRect)
[msg DATA tobii] =  tobii_command(tobii,'stop');

% CALIBRATION AND TESTING
for i=1:rep_num
    
    order=randperm(length(ExperimentType));
    
    for j=order
   
        % SET CALIBRATION/TEST TYPE
        switch j
            case 1
                Target=TargetCalib;
                calibType='B';
            case 2
                Target=TargetCalib;
                calibType='L';
            case 3
                Target=TargetCalib;
                calibType='R';
            case 4
                Target=TargetTest;
                calibType='B';
            case 5
                Target=TargetTest;   
                calibType='L';
            case 6
                Target=TargetTest; 
                calibType='R';
        end
         
        Screen(window,'FillRect',grey)
        Screen('Flip', window);

        FlushEvents; pause(0.2)
        
        % RUN CALIBRATION
        % START EYE TRACKER
        [msg DATA tobii] =  tobii_command(tobii,'start',[save_dir subject 'traj\' calibType num2str(i) '_']);
        CalibrationProcedure(tobii,Target,[save_dir subject '/DATA_' ExperimentType(j,:) num2str(i)],window,windowRect,calibType)
        [msg DATA tobii] =  tobii_command(tobii,'stop');
        
        Screen(window,'FillRect',grey)
        Screen('Flip', window);

        FlushEvents; pause(0.2)
        
         % Text output of mouse position draw in the centre of the screen
        DrawFormattedText(window, ['Press "q" to esc, or any key to continue...'], 'center', 100, white);
        
        % Flip to the screen
        Screen('Flip', window);

        FlushEvents; pause(0.2)
        [dumb exits] = KbWait;
        if exits(81)
            break;
        end

    end
    
    DrawFormattedText(window, ['TAKE A REST! Press "q" to esc, or any key to continue...'], 'center', 100, white);
    
end

% Clear the screen
sca;

% STOP EYE TRACKER
[msg DATA]= tobii_command(tobii,'stop');

% CLOSE SERVER AND UDP PORT
tobii_close(tobii)

