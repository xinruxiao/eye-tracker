%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Compute sampling frequency on single subjects' trial.

function D_TIME = ComputeSamplingFreq(load_calibL,load_calibR,load_testL,load_testR)

D_TIME=[];

%% CALIBRATION LEFT
load(load_calibL,'TIME_ALL')

for i=1:length(TIME_ALL)
    TIME(:,i)=TIME_ALL{i};
end

D_TIME=[D_TIME diff(TIME)];
% SF=[SF; 1./D_TIME(:)];

%% CALIBRATION RIGHT
load(load_calibR,'TIME_ALL')

for i=1:length(TIME_ALL)
    TIME(:,i)=TIME_ALL{i};
end

D_TIME=[D_TIME diff(TIME)];
% SF=[SF; 1./D_TIME(:)];

%% TEST LEFT
load(load_testL,'TIME_ALL')

for i=1:length(TIME_ALL)
    TIME(:,i)=TIME_ALL{i};
end

D_TIME=[D_TIME diff(TIME)];
% SF=[SF; 1./D_TIME(:)];

%% TEST RIGHT
load(load_testR,'TIME_ALL')

for i=1:length(TIME_ALL)
    TIME(:,i)=TIME_ALL{i};
end

D_TIME=[D_TIME diff(TIME)];
% SF=[SF; 1./D_TIME(:)];

D_TIME=D_TIME(:);

D_TIME(D_TIME<0.005)=[];