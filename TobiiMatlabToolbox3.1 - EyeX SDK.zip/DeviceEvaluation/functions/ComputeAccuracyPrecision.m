%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Compute accuracy and precision on a single subject trial.

function [ErrLL, ErrRR, PrecLL, PrecRR, TargetEcc] = ComputeAccuracyPrecision(load_calibL,load_calibR,load_testL,load_testR,MEAN_FLAG)

%% GLOBAL VARIABLES
global ANG_ERROR_L
global ANG_ERROR_R

global n

load(load_calibL)
load(load_calibR,'FR','RR')

%% SCREEN SIZE AND RESOLUTION
screen_res=[1600 900];
screen_sz_mm = [345 194];
px_sz_mm = screen_sz_mm./screen_res;

LPOS=nanmedian(LPOS');

screen_cntr_mm = screen_sz_mm/2 - LPOS(1:2);
    
XLIM_deg = atand([screen_cntr_mm(1)-screen_sz_mm(1) screen_cntr_mm(1) ]./LPOS(3));
YLIM_deg = atand([screen_cntr_mm(2)-screen_sz_mm(2) screen_cntr_mm(2)]./LPOS(3));

px_sz_deg=[diff(XLIM_deg)/screen_res(1), diff(YLIM_deg)/screen_res(2)];
screen_sz_deg=[diff(XLIM_deg), diff(YLIM_deg)];

%% CALIBRATION
Target(1,:)=screen_res(1)*(Target(1,:)-.5)*px_sz_deg(1);
Target(2,:)= screen_res(2)*(Target(2,:)-.5)*px_sz_deg(2);
    
TargetEcc=sqrt(sum(Target.^2));
TH_ANG_ERROR=2.9;

for nn=1:length(LL)    
    
    LLdeg{nn}(1,:)=screen_res(1)*(LL{nn}(1,61:end)-.5)*px_sz_deg(1);
    LLdeg{nn}(2,:)=screen_res(2)*(LL{nn}(2,61:end)-.5)*px_sz_deg(2);
    
    tmpLLangDist=sqrt((LLdeg{nn}(1,:)-Target(1,nn)).^2+(LLdeg{nn}(2,:)-Target(2,nn)).^2);
    tmpLLangDist(tmpLLangDist<nanmean(tmpLLangDist(:))-TH_ANG_ERROR*nanstd(tmpLLangDist(:)) | tmpLLangDist>nanmean(tmpLLangDist(:))+TH_ANG_ERROR*nanstd(tmpLLangDist(:)))=nan;
    LLangDist(:,nn)=tmpLLangDist;
    
    RRdeg{nn}(1,:)=screen_res(1)*(RR{nn}(1,61:end)-.5)*px_sz_deg(1);
    RRdeg{nn}(2,:)=screen_res(2)*(RR{nn}(2,61:end)-.5)*px_sz_deg(2);

    tmpRRangDist=sqrt((RRdeg{nn}(1,:)-Target(1,nn)).^2+(RRdeg{nn}(2,:)-Target(2,nn)).^2);
    tmpRRangDist(tmpRRangDist<nanmean(tmpRRangDist(:))-TH_ANG_ERROR*nanstd(tmpRRangDist(:)) | tmpRRangDist>nanmean(tmpRRangDist(:))+TH_ANG_ERROR*nanstd(tmpRRangDist(:)))=nan;
    RRangDist(:,nn)=tmpRRangDist;

end

ANG_ERROR_L(1:60,1:13,n)=LLangDist;
ANG_ERROR_R(1:60,1:13,n)=RRangDist;

ErrLL=nanmean(LLangDist);
ErrRR=nanmean(RRangDist);

PrecLL=nanstd(LLangDist);
PrecRR=nanstd(RRangDist);

clear LLdeg RRdeg LLangDist RRangDist

%% TEST
load(load_testL)
load(load_testR,'FR','RR')

Target(1,:)=screen_res(1)*(Target(1,:)-.5)*px_sz_deg(1);
Target(2,:)= screen_res(2)*(Target(2,:)-.5)*px_sz_deg(2);
    
TargetEcc=[TargetEcc sqrt(sum(Target.^2))];  
    
for nn=1:length(LL)    
    
    LLdeg{nn}(1,:)=screen_res(1)*(LL{nn}(1,61:end)-.5)*px_sz_deg(1);
    LLdeg{nn}(2,:)=screen_res(2)*(LL{nn}(2,61:end)-.5)*px_sz_deg(2);
    
    tmpLLangDist=sqrt((LLdeg{nn}(1,:)-Target(1,nn)).^2+(LLdeg{nn}(2,:)-Target(2,nn)).^2);
    tmpLLangDist(tmpLLangDist<nanmean(tmpLLangDist(:))-TH_ANG_ERROR*nanstd(tmpLLangDist(:)) | tmpLLangDist>nanmean(tmpLLangDist(:))+TH_ANG_ERROR*nanstd(tmpLLangDist(:)))=nan;
    LLangDist(:,nn)=tmpLLangDist;
    
    RRdeg{nn}(1,:)=screen_res(1)*(RR{nn}(1,61:end)-.5)*px_sz_deg(1);
    RRdeg{nn}(2,:)=screen_res(2)*(RR{nn}(2,61:end)-.5)*px_sz_deg(2);

    tmpRRangDist=sqrt((RRdeg{nn}(1,:)-Target(1,nn)).^2+(RRdeg{nn}(2,:)-Target(2,nn)).^2);
    tmpRRangDist(tmpRRangDist<nanmean(tmpRRangDist(:))-TH_ANG_ERROR*nanstd(tmpRRangDist(:)) | tmpRRangDist>nanmean(tmpRRangDist(:))+TH_ANG_ERROR*nanstd(tmpRRangDist(:)))=nan;
    RRangDist(:,nn)=tmpRRangDist;

end

ANG_ERROR_L(1:60,14:25,n)=LLangDist;
ANG_ERROR_R(1:60,14:25,n)=RRangDist;

n=n+1;

ErrLL=[ErrLL nanmean(LLangDist)];
ErrRR=[ErrRR nanmean(RRangDist)];

PrecLL=[PrecLL nanstd(LLangDist)];
PrecRR=[PrecRR nanstd(RRangDist)];

   
