%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Plot accuracy and precision on the subjects' dataset.


% %% LOAD DATA
% load DeviceAccuracyPrecision

%% DECIDE IF TO PLOT ACCURACY OR PRECISION
% % TEST_TYPE='accu';
% TEST_TYPE='prec';

%% LOAD TARGET ANGULAR POSITION
TargetC = loadTarget([load_dir subject '/DATA_CB' num2str(trial)]);
TargetT = loadTarget([load_dir subject '/DATA_TB' num2str(trial)]);

Target=[TargetC TargetT];

% ComputeEccentricity
Ecc=sqrt(sum(Target.^2,1));

[Ecc pos] = sort(Ecc);


switch TEST_TYPE
    case 'accu'
        %MONOCULAR & BINOCULAR
        % ERROR
        ERROR_M=cat(2,squeeze(ERR_LM),squeeze(ERR_RM),squeeze(ERR_LB),squeeze(ERR_RB));

    case 'prec'
        % PRECISION
        ERROR_M=cat(2,squeeze(PREC_LM),squeeze(PREC_LB),squeeze(PREC_RM),squeeze(PREC_RB));
end


ERROR_M=reshape(ERROR_M,[size(ERROR_M,1)*size(ERROR_M,2) size(ERROR_M,3) size(ERROR_M,4)]);
ERROR_M=ERROR_M(:,pos);

%% CLUSTER BY ECCENTRICITY
clust={[1], [2 3], [4 5], [6 7 8 9 10 11],[12 13 14 15],[16 17 18 19],[20 21],[22 23 24 23]};
for i=1:length(clust)
    
    tmp=squeeze(ERROR_M(:,clust{i})); tmp=tmp(:);
    
    MEAN_M(i)=nanmean(tmp);
    
    CONF_PLUS(i)=prctile(tmp,75);
    CONF_MINUS(i)=prctile(tmp,25);

    MAX_M(i)=prctile(tmp,95);
    MIN_M(i)=prctile(tmp,5);
    
    MED_M(i)=nanmedian(tmp);

end

EccX=[Ecc([1 2 4 6 12 16 20 22])];

%% LINEAR REGRESSION
f = fit(EccX',MED_M','poly1');


%% FIGURE
figure,hold on
wd=0.1;
errorbar(EccX,MED_M,MED_M-MIN_M,MAX_M-MED_M,'b','LineWidth',1)

for j=1:length(EccX)
    patch(EccX(j)+[-wd wd wd -wd -wd],[CONF_MINUS(j) CONF_MINUS(j) CONF_PLUS(j) CONF_PLUS(j) CONF_MINUS(j)],'b')
end
plot(EccX,MED_M,['s' 'b'] ,'MarkerFaceColor','c','color','k')

% PLOT LINEAR REGRESSION
plot(f,'k')
legend off

box on
set(gca,'XTick',EccX,'XTickLabel',round(EccX*10)/10)
set(gca,'YTick',0:.05:1)

xlabel('Target Eccentricity [deg]')
xlim([-1 13.2])

grid on

switch TEST_TYPE
    case 'accu'
        ylabel('Accuracy [deg]')
    case 'prec'
        ylabel('Precision [deg]')
end





