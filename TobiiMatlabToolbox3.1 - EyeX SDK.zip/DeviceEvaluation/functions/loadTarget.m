%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Load target position on screen [deg].

function Target = loadTarget(load_data)

load(load_data,'Target','LPOS')

%% SCREEN SIZE AND RESOLUTION
screen_res=[1600 900];
screen_sz_mm = [345 194];

LPOS=nanmedian(LPOS');

screen_cntr_mm = screen_sz_mm/2 - LPOS(1:2);
    
XLIM_deg = atand([screen_cntr_mm(1)-screen_sz_mm(1) screen_cntr_mm(1) ]./LPOS(3));
YLIM_deg = atand([screen_cntr_mm(2)-screen_sz_mm(2) screen_cntr_mm(2)]./LPOS(3));

px_sz_deg=[diff(XLIM_deg)/screen_res(1), diff(YLIM_deg)/screen_res(2)];

Target(1,:)=screen_res(1)*(Target(1,:)-.5)*px_sz_deg(1);
Target(2,:)= screen_res(2)*(Target(2,:)-.5)*px_sz_deg(2);

