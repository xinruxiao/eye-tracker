%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CODE FOR DEVICE EVALUATION (ACCURACY, PRECISION AND SAMPLING FREQUENCY)
% Compute sampling frequency on the subjects' dataset.

clear, close all, clc

%% MANAGE DIRECTORIES
addpath functions
addpath ../tobii_matlab
load_dir='DATA/';

subject_list=dir(load_dir); subject_list(1:2)=[];

%% LOAD SAMPLING FREQUENCY
trial_num=4;
SF=[];
for s=1:length(subject_list)
    
    subject=subject_list(s).name;
    display(['LOADING SUBJECT: ' subject])
    
    for trial=1:trial_num
        
        display(['TRIAL: ' num2str(trial)])
        
        SF = [SF; ComputeSamplingFreq(...
            [load_dir subject '/DATA_CB' num2str(trial)],[load_dir subject '/DATA_CB' num2str(trial)],...
            [load_dir subject '/DATA_TB' num2str(trial)],[load_dir subject '/DATA_TB' num2str(trial)])];

        SF = [SF; ComputeSamplingFreq(...
            [load_dir subject '/DATA_CL' num2str(trial)],[load_dir subject '/DATA_CR' num2str(trial)],...
            [load_dir subject '/DATA_TL' num2str(trial)],[load_dir subject '/DATA_TR' num2str(trial)])];
        
    end
end

%% DATA SAVE
save DeviceSamplingFrequency

%% SHOW RESULTS
display(['MEAN SAMPLING FREQ: ' num2str(1./nanmean(SF)) ' +/- ' num2str(1/nanmean(SF) - 1/(iqr(SF)+nanmean(SF)))])
display(['MEDIAN SAMPLING FREQ: ' num2str(1./nanmedian(SF)) ' +/- ' num2str(1/nanmedian(SF) - 1/(iqr(SF)+nanmedian(SF)))])



