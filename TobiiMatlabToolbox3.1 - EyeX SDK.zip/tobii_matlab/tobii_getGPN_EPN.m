%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [Leye, Reye, Lgaze, Rgaze, time] = tobii_getGPN_EPN(tobii)
% GET GAZE POINT NORMALIZED ON DISPLAY AND EYE POSITION NORMALIZED IN TRACKBOX
% function [Leye, Reye, Lgaze, Rgaze, time] = tobii_getGPN_EPN(tobii)
% INPUT:
% tobii - Matlab udp object
% OUTPUT:
% Leye - left normalized gaze position 
% Reye - right normalized gaze position 
% Lgaze - left normalized gaze position 
% Rgaze - right normalized gaze position 
% Time - timestamp

% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA = fread(tobii,4,'double'); % READ INIT RESULT

CHK1 = ~isempty(DATA);

if CHK1
    CHK2 = length(DATA)==24;
end

if CHK1 && CHK2
    
    Leye = DATA(12:13);
    Leye(1) = Leye(1) ./ 1920;
    Leye(2) = Leye(2) ./ 1080;
    
    Reye = DATA(23:24);
    Reye(1) = Reye(1) ./ 1920;
    Reye(2) = Reye(2) ./ 1080;
    
    Lgaze = DATA(6:8);
    Rgaze = DATA(17:19);
    
    
    time = DATA(2);
else
    Lgaze = [nan nan nan]';
    Rgaze = [nan nan nan]';
    Leye = [nan nan]';
    Reye = [nan nan]';
    time = nan;
end

