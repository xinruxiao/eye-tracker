%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [msg, DATA, tobii]= tobii_command(tobii,command,arg)
% function [msg DATA]= tobii_command(tobii,command,arg)
% INPUT:
% tobii - Matlab udp object
% command - command to be sent to the server ('init', 'start', 'read', 'stop')
% arg - argument of the command to be sent to the server
% OUTPUT:
% msg - message check of correct data received
% DATA - data requested to the EyeX


if nargin < 3
    arg ='';
end

if strcmp(tobii.Status,'closed')
    global global_server_path
    tobii  =  tobii_connect(global_server_path);
    % INITIALIZE EYE TRACKER
    [msg DATA] =  tobii_command(tobii,'init');
end

switch command
    case 'init'
        command = 64;
        [DATA, msg, tobii] = tobii_init_connection(tobii); % CHK SUCCESSFULL INIT
    case 'start'
        command = 65;
        % CHK SUCCESSFULL CONNECTION
        [DATA, msg, tobii] = tobii_chk_connection(tobii,arg);
%         fwrite(tobii,[command arg]) % READ DATA
    case 'read'
        command = 66;
        fwrite(tobii,[command arg]) % SEND COMMAND TO READ DATA
        DATA = fread(tobii,4,'double'); % READ DATA
    case 'stop'
        command = 67;
        [DATA, msg, tobii] = tobii_stop(tobii);
%         fwrite(tobii,[command arg]) %  SEND COMMAND TO STOP
%         pause(2)
%         DATA = fread(tobii,4,'double'); % READ DATA
%                 DATA(1)
end

% SEND MESSAGE TO THE SERVER
% fwrite(tobii,[command arg])
% READ RESPONSE FROM THE SERVER
% DATA=[];
% [DATA, count, msg] = fread(tobii,4,'double'); % READ INIT RESULT

%% CHK IF THE OPERATION WAS SUCCESSFUL
if ~isempty(DATA)
    msg = true;  % COMMAND SUCCESS
else
    msg = false; % COMMAND FAILURE
end
