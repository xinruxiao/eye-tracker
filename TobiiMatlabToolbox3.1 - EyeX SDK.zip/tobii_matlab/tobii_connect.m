%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function tobii = tobii_connect(server_path,ip_address)
% function tobii = tobii_connect()
% INPUT:
% server_path - path to the server
% ip_address - IP of the machine where EyeX is connected
% OUTPUT:
% tobii - Matlab udp object

if nargin < 2    
    ip_address = '--auto';
end

if nargin < 1  || isempty(server_path)  
    server_path = [pwd '\matlab_server\'];
end

global global_server_path 
global_server_path = server_path;

%% Launch server through Matlab
system([server_path 'EyeXMatlabServer.exe ' ip_address ' &']);

%% Open UDP port through Matlab
tobii = udp('127.0.0.1',50102);

%% SET TIMEOUT PERIOD
tobii.TimeOut=1/20;

fopen(tobii);
