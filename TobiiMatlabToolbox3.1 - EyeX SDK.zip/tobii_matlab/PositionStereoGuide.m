  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 3.1										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) May 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [Lpos, Rpos] = PositionStereoGuide(tobii,window,windowRect)
% VISUALIZE AND RETURN THE EYE POSITION AND DISTANCE WITH RESPECT TO THE SCREEN CENTER (requires the PsychoToolbox)
% function [Lpos Rpos] = PositionGuide(tobii,window,windowRect)
% INPUT:
% tobii - Matlab udp object
% window - 
% windowRect - 
% OUTPUT:
% Lpos - mean left normalized eye position kept during the last second
% Rpos - mean right normalized eye position kept during the last second



% Set circles paramentes
eye_size=100;
FixedColor  = [0 1 1 1];
baseRect = eye_size.*[0 0 1 1];
penWidthPixels = 2;

FlushEvents

Lold=[0 0 0]';
Rold=[0 0 0]';

while ~KbCheck
    Screen(window,'FillRect',0.5)

    Screen('SelectStereoDrawBuffer', window, 0);
    DrawFormattedText(window, ['Position yourself in the center of the screen.'], 'center', 100, 1);
    DrawFormattedText(window, ['Press any key to continue...'], 'center', 200, 1);
    Screen('SelectStereoDrawBuffer', window, 1);
    DrawFormattedText(window, ['Position yourself in the center of the screen.'], 'center', 100, 1);
    DrawFormattedText(window, ['Press any key to continue...'], 'center', 200, 1);

    
    [L, R] = tobii_getEPN(tobii);

    if any(L~=Lold)
        gainL=(1-L(3));
    else
        gainL=nan;
    end
    
    if any(R~=Rold)
        gainR=(1-R(3));
     else
        gainR=nan;
    end
    
    Cyclo=(L+R)/2;
    dist=sqrt(sum((Cyclo-[.5; .5; .5]).^2));
    
    if dist<.25;
        colour=[0 255 0];
    elseif dist<.5
        colour=[128 128 0];
    else
        colour=[255 0 0];
    end
    
    baseRectL = baseRect + baseRect.*gainL;
    baseRectR = baseRect + baseRect.*gainR;
    
    RectTarget1  = CenterRectOnPointd(baseRectL, windowRect(3).*(1-L(1)), windowRect(4).*L(2));
    RectTarget2  = CenterRectOnPointd(baseRectR, windowRect(3).*(1-R(1)), windowRect(4).*R(2));
    
    Screen('SelectStereoDrawBuffer', window, 0);
    Screen('FillOval', window, colour, RectTarget1);
    Screen('FillOval', window, colour, RectTarget2);

    Screen('SelectStereoDrawBuffer', window, 1);
    Screen('FillOval', window, colour, RectTarget1);
    Screen('FillOval', window, colour, RectTarget2);

    Screen('Flip', window);
    
    Lold=L;
    Rold=R;
    
    pause(1/30)

end

%% ACQUIRE FINAL POSITION
for i=1:30
    [L(:,i), R(:,i)] = tobii_getEPM(tobii);
end

Lpos=nanmedian(L,2);
Rpos=nanmedian(R,2);




