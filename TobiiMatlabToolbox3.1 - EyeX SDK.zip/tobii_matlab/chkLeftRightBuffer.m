%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 3.1										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) May 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function LRbuf = chkLeftRightBuffer(window,windowRect,LRbuf)
% CHECK LEFT/RIGHT BUFFER
%(requires the PsychoToolbox)
% LRbuf = chkLeftRightBuffer(window,windowRect,LRbuf)
% INPUT:
% window - window index (PTB)
% windowRect - window size in pixel (PTB)
% LRbuf - (optional) guess of which is left buffer and which is right (default: LeftBUF % = 0; RightBUF = 1;)
% OUTPUT:
% LRbuf - define which is left buffer and which is right
%         0 (dafault) (LeftBUF % = 0; RightBUF = 1;) 
%         1           (LeftBUF % = 1; RightBUF = 0;) 

if nargin < 3
    LRbuf = 0; 
end


% Define black and white
white = 1;
black = 0;
grey  = (white+black)/2;

% flag
STOP =1;

FlushEvents;pause(0.1);FlushEvents;
while(STOP)

    if LRbuf == 0
        Screen('SelectStereoDrawBuffer', window, 0);
        DrawFormattedText(window, ['Is this left screen? Press SPACE to switch, ESC to exit.'], 'center', 100, white);
    elseif LRbuf ==1
        Screen('SelectStereoDrawBuffer', window, 1);
        DrawFormattedText(window, ['Is this left screen? Press SPACE to switch, ESC to exit.'], 'center', 100, white);
    end
    
    Screen('Flip', window);
    
    [secs, keyCode, deltaSecs] = KbPressWait; 
    
    if find(keyCode,1)==32 % SPACEBAR
        
        LRbuf = mod(LRbuf+3,2);
        
    end

    if find(keyCode,1)==27 %ESC
        STOP=0;
    end

end






