%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function Time = tobii_getTIME(tobii)
% GET TIMESTAMP
% function time = tobii_getTIME(tobii)
% INPUT:
% tobii - Matlab udp object
% OUTPUT:
% Time - timestamp

% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA = fread(tobii,4,'double'); % READ INIT RESULT

try
    Time = DATA(2);
catch
    Time = nan;
end