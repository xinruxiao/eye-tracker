%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Lc, Rc] = tobii_GPNcalibGRID(L, R, CalibL, CalibR)
% GAZE POINT CALIBRATION GRID NORMALIZED ON DISPLAY


Lc = cat(3,CalibL{1}(L(:,:,1),L(:,:,2)), CalibL{2}(L(:,:,1),L(:,:,2)));
Rc = cat(3,CalibR{1}(R(:,:,1),R(:,:,2)), CalibR{2}(R(:,:,1),R(:,:,2)));