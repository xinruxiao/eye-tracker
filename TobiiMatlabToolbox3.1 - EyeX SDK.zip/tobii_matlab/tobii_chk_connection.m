%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [DATA, msg, tobii] = tobii_chk_connection(tobii,arg)

global global_server_path
CHK=false;
n=0;

CHK1=false; % EMPTY DATA
CHK2=false; % TOBII COMMUNICATION ERROR

while ~CHK && n<=10
    
    n=n+1;
    DATA=[];
    
    command = 65;
    
    if strcmp(tobii.Status,'closed')
        CHK1=true;
    else
        fwrite(tobii,[65 arg]) % START AND OPEN txt FILE NAMED arg
        [DATA, count, msg] = fread(tobii,4,'double'); % READ INIT RESULT
        
        % CHK FOR EMPTY DATA (TIMEOUT)
        CHK1=isempty(DATA);
        
        % CHK FOR CONNECTION PROBLEMS
        if ~CHK1
            CHK2=DATA(1)>0;
        else
            CHK2=true;
        end
    end
    
    if CHK1 || CHK2
        % CLOSE UNSUCCESFULL UDP
        tobii_close(tobii);
        % START SERVER AND OPEN UDP PORT
        tobii  =  tobii_connect(global_server_path);
        % INITIALIZE EYE TRACKER
        [msg DATA] =  tobii_command(tobii,'init');
    else
        CHK=true;
    end
    
end
