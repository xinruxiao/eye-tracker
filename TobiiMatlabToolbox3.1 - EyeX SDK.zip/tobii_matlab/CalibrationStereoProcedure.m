%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 3.1										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) May 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [CalibL, CalibR] = CalibrationStereoProcedure(tobii,Target,save_dir,window,windowRect,calibType,LRbuf)
% CALIBRATION PROCEDURE
%(requires the PsychoToolbox)
% CalibrationBinocularSetPrecise(tobii,Target,save_dir,window,windowRect,calibType)
% INPUT:
% tobii - Matlab udp object
% Target - Nx2 vector containing the N normalized coordinates (X and Y) of the targets used for the calibration
% save_dir - directory where the calibration parameters are saved
% window - window index (PTB)
% windowRect - window size in pixel (PTB)
% calybType - flag defining whic calibration to perform: 'B' binocular (default), 'L' left monocular, 'R' right monocular
% LRbuf - define which is left buffer and which is right (default: LeftBUF % = 0; RightBUF = 1;)
% OUTPUT:
% CalibL - 1x2 structure containing the calibration fit function for the X and Y gaze estimation for the left eye
% CalibR - 1x2 structure containing the calibration fit function for the X and Y gaze estimation for the right eye

if nargin < 7 || LRbuf == 0
    % DEFAULT LEFT/RIGHT BUFFER
    LeftBUF = 0;
    RightBUF = 1;
else
    LeftBUF = 1;
    RightBUF = 0;
end

if nargin <6
    calibTYPE='B';
end


% Define black and white
white = 1;
black = 0;
grey  = (white+black)/2;

% Get the centre coordinate of the window
[xCenter, yCenter] = RectCenter(windowRect);

% [xgrid ygrid]=meshgrid(min(Target(:)):0.01:max(Target(:)));

stepx=0.01; stepy=stepx;
[xgrid, ygrid]=meshgrid(min(Target(:))-0.05:stepx:max(Target(:))+0.05);
dominium=cat(3,xgrid,ygrid);

[xCenter, yCenter] = RectCenter(windowRect);
dotCenter = [xCenter yCenter];

% Set circles paramentes
FixedColor  = [0 1 1 1];
baseRect = [0 0 30 30];
% Pen width for the frames
penWidthPixels = 2;

% Loop the animation until a key is pressed
FlushEvents; FlushEvents;


fixation_time=2;
sample_num=fixation_time*60;

for count=1:60
    [LPOS(:,count), RPOS(:,count)] = tobii_getEPM(tobii);
end

remove=0.5*60;
count =1;

%% PART 1
gain_size = fliplr(linspace(0.2,1,60));
mask_correct=false(1,size(Target,2));

switch calibType
    case 'L'
        Screen('SelectStereoDrawBuffer', window, LeftBUF);
        DrawFormattedText(window, ['LEFT. Press "q" to esc, or any key to continue...'], 'center', 100, white);
        display('L')
    case 'R'
        Screen('SelectStereoDrawBuffer', window, RightBUF);
        DrawFormattedText(window, ['RIGHT. Press "q" to esc, or any key to continue...'], 'center', 100, white);
        display('R')
    case 'B'
        Screen('SelectStereoDrawBuffer', window, LeftBUF);
        DrawFormattedText(window, ['BINOCULAR. Press "q" to esc, or any key to continue...'], 'center', 100, white);
        Screen('SelectStereoDrawBuffer', window, RightBUF);
        DrawFormattedText(window, ['BINOCULAR. Press "q" to esc, or any key to continue...'], 'center', 100, white);
        display('B')
end

% Flip to the screen
Screen('Flip', window);

FlushEvents;
pause(0.2)
[dumb exits] = KbWait;

Screen(window,'FillRect',grey)

Screen('Flip', window);

FlushEvents;
pause(0.2)


repetition = 0;
while any(mask_correct==false) && repetition<2
    
    for disp_point=1:size(Target,2)
        
        if mask_correct(disp_point)==false
            RectTarget1  = CenterRectOnPointd(baseRect, windowRect(3).*Target(1,disp_point), windowRect(4).*Target(2,disp_point));
            RectTarget2  = CenterRectOnPointd(0.2.*baseRect, windowRect(3).*Target(1,disp_point), windowRect(4).*Target(2,disp_point));
            
            switch calibType
                case 'L'
                    Screen('SelectStereoDrawBuffer', window, LeftBUF);
                    Screen('FillOval',  window, [255 255 255], RectTarget1);
                    Screen('FillOval', window, [0 0 0], RectTarget2);
                case 'R'
                    Screen('SelectStereoDrawBuffer', window, RightBUF);
                    Screen('FillOval',  window, [255 255 255], RectTarget1);
                    Screen('FillOval', window, [0 0 0], RectTarget2);
                case 'B'
                    Screen('SelectStereoDrawBuffer', window, LeftBUF);
                    Screen('FillOval',  window, [255 255 255], RectTarget1);
                    Screen('FillOval', window, [0 0 0], RectTarget2);
                    Screen('SelectStereoDrawBuffer', window, RightBUF);
                    Screen('FillOval',  window, [255 255 255], RectTarget1);
                    Screen('FillOval', window, [0 0 0], RectTarget2);
            end
                    
            % Flip to the screen
            Screen('Flip', window);
            
            pause(.5)
            
            TIME=0;
            count=1;
            [L(:,count), R(:,count), time_init] = tobii_getGPN(tobii);
            
            % FIXED
            tic
            for count=1:sample_num/2
                
                [L(:,count), R(:,count)] = tobii_getGPN(tobii);
                
                TIME(count) = toc;
                
            end
            
            %SHRINKING
            count_size=1;
            for count=1+sample_num/2:sample_num
                
                [L(:,count), R(:,count)] = tobii_getGPN(tobii);
                
                TIME(count) = toc;
                
                RectTarget1  = CenterRectOnPointd(baseRect.*gain_size(count_size), windowRect(3).*Target(1,disp_point), windowRect(4).*Target(2,disp_point));
                
                switch calibType
                    case 'L'
                        Screen('SelectStereoDrawBuffer', window, LeftBUF);
                        Screen('FillOval',  window, [255 255 255], RectTarget1);
                        Screen('FillOval', window, [0 0 0], RectTarget2);
                    case 'R'
                        Screen('SelectStereoDrawBuffer', window, RightBUF);
                        Screen('FillOval',  window, [255 255 255], RectTarget1);
                        Screen('FillOval', window, [0 0 0], RectTarget2);
                    case 'B'
                        Screen('SelectStereoDrawBuffer', window, LeftBUF);
                        Screen('FillOval',  window, [255 255 255], RectTarget1);
                        Screen('FillOval', window, [0 0 0], RectTarget2);
                        Screen('SelectStereoDrawBuffer', window, RightBUF);
                        Screen('FillOval',  window, [255 255 255], RectTarget1);
                        Screen('FillOval', window, [0 0 0], RectTarget2);
                end
                
                % Flip to the screen
                Screen('Flip', window);
                count_size=count_size+1;
            end
            
            pause(0.2)
            
            LL{disp_point}=L;
            RR{disp_point}=R;
            TIME_ALL{disp_point}=TIME;
            
            %COMPUTE FIXED POINTS
            FL(:,disp_point)=nanmedian(LL{disp_point}(:,remove:end),2);
            FR(:,disp_point)=nanmedian(RR{disp_point}(:,remove:end),2);
            
            clear L R TIME
            
        end
        
        
    end
    
    % COMPUTE AND CHAK MEAN ERROR
    ERROR_L=FL - Target; ERROR_L=ERROR_L-repmat(nanmedian(ERROR_L,2),[1 length(ERROR_L)]);
    ERROR_R=FR - Target; ERROR_R=ERROR_R-repmat(nanmedian(ERROR_R,2),[1 length(ERROR_R)]);
    
    CALIB_TH=0.03;
    if calibType=='L'
        mask_correct=abs(ERROR_L)<CALIB_TH;
    elseif calibType=='R'
        mask_correct=abs(ERROR_R)<CALIB_TH;
    else
        mask_correct=abs(ERROR_L)<CALIB_TH & abs(ERROR_R)<CALIB_TH;
    end
    
    mask_correct=mask_correct(1,:) & mask_correct(2,:);
    
    repetition=repetition+1;
end

%% GREY SCREEN
Screen('SelectStereoDrawBuffer', window, LeftBUF);
Screen(window,'FillRect',grey)
Screen('SelectStereoDrawBuffer', window, RightBUF);
Screen(window,'FillRect',grey)
Screen('Flip', window);

FlushEvents;
pause(0.2)

%% COMPUTE FIRST CALIB GRID

[XLfit, XLgof] = CalibFit(Target(1,:), Target(2,:), Target(1,:)-FL(1,:), 0);
[YLfit, YLgof] = CalibFit(Target(1,:), Target(2,:), Target(2,:)-FL(2,:), 0);

[XRfit, XRgof] = CalibFit(Target(1,:), Target(2,:), Target(1,:)-FR(1,:), 0);
[YRfit, YRgof] = CalibFit(Target(1,:), Target(2,:), Target(2,:)-FR(2,:), 0);

CalibL{1}=XLfit;
CalibL{2}=YLfit;
CalibR{1}=XRfit;
CalibR{2}=YRfit;


save(save_dir)


