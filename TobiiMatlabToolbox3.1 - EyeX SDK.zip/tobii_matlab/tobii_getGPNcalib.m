%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [Lc, Rc, time] = tobii_getGPNcalib(tobii, CalibL, CalibR)
% ACQUIRE THE GAZE POINT NORMALIZED ON DISPLAY AND APPLY THE CALIBRATION ONLINE
% function [Lc, Rc] = tobii_getGPNcalib(tobii, CalibL, CalibR)
% INPUT:
% tobii - Matlab udp object
% CalibL - calibration fit object for left eye
% CalibR - calibration fit object for right eye
% OUTPUT:
% Lc - calibrated left normalized gaze position 
% Rc - calibrated right normalized gaze position 

% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA=[];
[DATA, count, msg] = fread(tobii,4,'double'); % READ INIT RESULT

CHK1 = ~isempty(DATA);

if CHK1
    CHK2 = length(DATA)==24;
end

if CHK1 && CHK2
    
    L = DATA(12:13);
    L(1) = L(1) ./ 1920;
    L(2) = L(2) ./ 1080;
    
    R = DATA(23:24);
    R(1) = R(1) ./ 1920;
    R(2) = R(2) ./ 1080;
    
    Lc = L + [CalibL{1}(L(1),L(2)); CalibL{2}(L(1),L(2))];
    Rc = R + [CalibR{1}(R(1),R(2)); CalibR{2}(R(1),R(2))];
    
    time = DATA(2);

    
else
    
    Lc = [nan nan]';
    Rc = [nan nan]';
    
    time = nan;
    
end