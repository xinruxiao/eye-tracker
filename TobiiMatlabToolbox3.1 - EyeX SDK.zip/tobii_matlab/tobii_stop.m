%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [DATA, msg, tobii] = tobii_stop(tobii)

arg = '';
DATA = [];

global global_server_path

CHKclosed = strcmp(tobii.Status,'closed');
CHK1=false;
CHK2=false;

command = 67;

if ~CHKclosed

    fwrite(tobii,[command arg]) %  SEND COMMAND TO STOP
    pause(2)
    DATA = fread(tobii,4,'double'); % READ DATA
    
    % CHK FOR EMPTY DATA (TIMEOUT)
    CHK1=isempty(DATA);
    
    % CHK FOR CONNECTION PROBLEMS
    if ~CHK1
        CHK2=DATA(1)>0;
        msg = 1;
    else
        CHK2=true;
    end
    
else
    CHK1=true;
end

% Close and re-initialize EyeX
if CHK1 || CHK2
    % CLOSE UNSUCCESFULL UDP
    if ~CHKclosed
        tobii_close(tobii);
    end
    % START SERVER AND OPEN UDP PORT
    tobii  =  tobii_connect(global_server_path);
    % INITIALIZE EYE TRACKER
    [msg DATA tobii] =  tobii_command(tobii,'init');
else
    CHK=true;
end