  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 1.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) May 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [Lpos Rpos] = CalibrationCheck(tobii,window,windowRect,Target,CalibL,CalibR)
% VISUALIZE THE EYE POSITION AND DISTANCE WITH RESPECT TO THE SCREEN CENTER 
% VISUALIZE A SET OF TARGETS AND A GAZE THRESHOLD ERROR
% RETURN THE EYE POSITION (IN mm) WITH RESPECT TO THE SCREEN CENTER
%(requires the PsychoToolbox)
% function [Lpos Rpos] = PositionGuide(tobii,window,windowRect)
% INPUT:
% tobii - Matlab udp object
% window - window index (PTB)
% windowRect - window size in pixel (PTB)
% Target  - 2xN array containing the target position
% CalibL - calibration fit function for the left eye
% CalibR - calibration fit function for the right eye
% OUTPUT:
% Lpos - mean left normalized eye position kept during the last second
% Rpos - mean right normalized eye position kept during the last second

% Set target position
if nargin<4
Target=[0.5 0.05 0.95 0.05 0.95;...
        0.5 0.05 0.05 0.95 0.95];
end

% Set circles paramentes
eye_size=100;
FixedColor  = [0 1 1 1];
baseRectEye = eye_size.*[0 0 1 1];
penWidthPixels = 2;


% Get the centre coordinate of the window
[xCenter, yCenter] = RectCenter(windowRect);
dotCenter = [xCenter yCenter];

% Set circles paramentes
FixedColor  = [0 1 1 1];
baseRect = [0 0 30 30];
% Pen width for the frames
penWidthPixels = 2;


% Flip to the screen
Screen('Flip', window);

Lold=[0 0 0]';
Rold=[0 0 0]';

FlushEvents
while ~KbCheck
    Screen(window,'FillRect',0.5)

    DrawFormattedText(window, ['Position yourself in the center of the screen.'], 'center', 100, 1);
    DrawFormattedText(window, ['Press any key to continue...'], 'center', 200, 1);

    [L, R, Lpos, Rpos, time] = tobii_getGPN_EPN(tobii);
    
    
    
%     try
% 	[L R]=tobii_GPNcalib(L,R,CalibL,CalibR);
%     catch
%         aa==0;
%     end

    %% FIXATION POINTS
    RectTargetLE  = CenterRectOnPointd(0.3.*baseRect, windowRect(3).*L(1), windowRect(4).*L(2));
    RectTargetRE  = CenterRectOnPointd(0.3.*baseRect, windowRect(3).*R(1), windowRect(4).*R(2));
    Screen('FillOval',  window, [255 255 255], RectTargetLE);
    Screen('FillOval',  window, [255 255 255], RectTargetRE);
    
    %% FIXATION TARGET
    try
    Ldist=sqrt(nansum((repmat(L,[1 size(Target,2)])-Target).^2,1));
    Rdist=sqrt(nansum((repmat(R,[1 size(Target,2)])-Target).^2,1));
    catch
        aa=0;
    end
    [MinL FixL]=min(Ldist);
    [MinR FixR]=min(Rdist);
    
    if MinL<MinR
        FIX=FixL;
    else
        FIX=FixR;
    end
    
    for disp_point=1:size(Target,2)
        
        RectTarget1  = CenterRectOnPointd(baseRect, windowRect(3).*Target(1,disp_point), windowRect(4).*Target(2,disp_point));
        RectTarget2  = CenterRectOnPointd(0.2.*baseRect, windowRect(3).*Target(1,disp_point), windowRect(4).*Target(2,disp_point));
            
        if disp_point==FIX
            Screen('FillOval',  window, [255 0 0], RectTarget1);
        else
            Screen('FillOval',  window, [255 255 255], RectTarget1);
        end
        
        Screen('FillOval', window, [0 0 0], RectTarget2);
        
    end
    
    %% EYE POSITION
    if any(Lpos~=Lold)
        gainL=(1-Lpos(3));
    else
        gainL=nan;
    end
    
    if any(Rpos~=Rold)
        gainR=(1-Rpos(3));
     else
        gainR=nan;
    end
    
    Cyclo=(Lpos+Rpos)/2;
    dist=sqrt(sum((Cyclo-[.5; .5; .5]).^2));
    
    if Ldist(FIX)<.02;
        colourL=[0 255 0];
    elseif Ldist(FIX)<.08
        colourL=[128 128 0];
    else
        colourL=[255 0 0];
    end
    
    if Rdist(FIX)<.02;
        colourR=[0 255 0];
    elseif Rdist(FIX)<.08
        colourR=[128 128 0];
    else
        colourR=[255 0 0];
    end
    
    baseRectL = baseRectEye + baseRectEye.*gainL;
    baseRectR = baseRectEye + baseRectEye.*gainR;
    
    RectTargetL  = CenterRectOnPointd(baseRectL, windowRect(3).*(1-Lpos(1)), windowRect(4).*Lpos(2));
    RectTargetR  = CenterRectOnPointd(baseRectR, windowRect(3).*(1-Rpos(1)), windowRect(4).*Rpos(2));
    
    Screen('FillOval', window, colourL, RectTargetL);
    Screen('FillOval', window, colourR, RectTargetR);

    Screen('Flip', window);
    
    Lold=Lpos;
    Rold=Rpos;
    
    pause(1/30)

end

%% ACQUIRE FINAL POSITION
for i=1:30
    [Lpos(:,i), Rpos(:,i)] = tobii_getEPM(tobii);
end

Lpos=nanmedian(Lpos,2);
Rpos=nanmedian(Rpos,2);




