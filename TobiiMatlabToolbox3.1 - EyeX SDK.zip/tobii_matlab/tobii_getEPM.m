%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [L, R, time] = tobii_getEPM(tobii)
% GET EYE POSITION IN mm
% function [L, R, time] = tobii_getEPM(tobii)
% INPUT:
% tobii - Matlab udp object
% OUTPUT:
% L - left eye position in mm
% R - right eye position in mm
% Time - timestamp


% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA = fread(tobii,4,'double'); % READ INIT RESULT

CHK1 = ~isempty(DATA);

if CHK1
    CHK2 = length(DATA)==24;
end

if CHK1 && CHK2
    L = DATA(3:5);
    R = DATA(14:16);
    time = DATA(2);
else
    L = [nan nan nan]';
    R = [nan nan nan]';
    time = nan;
end
