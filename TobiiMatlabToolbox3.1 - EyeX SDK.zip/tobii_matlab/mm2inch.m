function IN = mm2inch(MM)
% function IN = mm2inch(MM)
% CONVERT [mm] to [inch]

f = 25.4;

IN = MM.*f;