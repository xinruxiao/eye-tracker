%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [L, R, time] = tobii_getEPN(tobii)
% GET EYE POSITION NORMALIZED IN TRACKBOX
% function [L, R, time] = tobii_getEPN(tobii)
% INPUT:
% tobii - Matlab udp object
% OUTPUT:
% L - left eye normalized position 
% R - right eye normalized position 
% Time - timestamp

% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA = fread(tobii,4,'double'); % READ INIT RESULT

CHK1 = ~isempty(DATA);

if CHK1
    CHK2 = length(DATA)==24;
end

if CHK1 && CHK2
    L = DATA(6:8);
    R = DATA(17:19);
    time = DATA(2);
else
    L = [nan nan nan]';
    R = [nan nan nan]';
    time = nan;
end
