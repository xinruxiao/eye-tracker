%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  function [Lc, Rc] = tobii_GPNcalib(L, R, CalibL, CalibR)
% APPLY THE CALIBRATION TO the GAZE POINT NORMALIZED ON DISPLAY
% function [Lc, Rc] = tobii_GPNcalib(L, R, CalibL, CalibR)
% INPUT:
% L - left normalized gaze position 
% R - right normalized gaze position 
% CalibL - calibration fit object for left eye
% CalibR - calibration fit object for right eye
% OUTPUT:
% Lc - calibrated left normalized gaze position 
% Rc - calibrated right normalized gaze position 

Lc = L + [CalibL{1}(L(1,:),L(2,:)); CalibL{2}(L(1,:),L(2,:))];
Rc = R + [CalibR{1}(R(1,:),R(2,:)); CalibR{2}(R(1,:),R(2,:))];