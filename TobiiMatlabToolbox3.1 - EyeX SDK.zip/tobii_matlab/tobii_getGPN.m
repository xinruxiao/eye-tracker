%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [L, R, time] = tobii_getGPN(tobii)
% GET GAZE POINT NORMALIZED ON DISPLAY
% function [L, R, time] = tobii_getGPN(tobii)
% INPUT:
% tobii - Matlab udp object
% OUTPUT:
% L - left normalized gaze position 
% R - right normalized gaze position 
% Time - timestamp

% SEND MESSAGE TO THE SERVER
fwrite(tobii,[66 ''])
% READ RESPONSE FROM THE SERVER
DATA = fread(tobii,4,'double'); % READ INIT RESULT

CHK1 = ~isempty(DATA);

if CHK1
    CHK2 = length(DATA)==24;
end

if CHK1 && CHK2
    L = DATA(12:13);
    L(1) = L(1) ./ 1920;
    L(2) = L(2) ./ 1080;
    
    R = DATA(23:24);
    R(1) = R(1) ./ 1920;
    R(2) = R(2) ./ 1080;
    
    time = DATA(2);
else
    L = [nan nan]';
    R = [nan nan]';
    time = nan;
end
