%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 	MATLAB TOOLBOX for EYEX ver 2.0										%%%%
%%%%																		%%%%
%%%% 	Copyright (c) Sep. 2015												%%%%
%%%% 	All rights reserved.												%%%%
%%%%																		%%%%
%%%% 	Authors: Mauricio Vanegas, Agostino Gibaldi, Guido Maiello			%%%%
%%%%          																%%%%
%%%% 	PSPC-lab - Department of Informatics, Bioengineering, 				%%%%
%%%% 	Robotics and Systems Engineering - University of Genoa				%%%%
%%%%																		%%%%
%%%% 	The Toolbox is released for free use for SCIENTIFIC RESEARCH ONLY.  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fitresult, gof] = CalibFit(xData, yData, ErrorData, show_fig, ft)
% FIT THE ESTIMATION ERROR OF THE NORMALIZED GAZE POSITION WITH A SURFACE 
% [fitresult, gof] = CalibFit(xData, yData, ErrorData, show_fig, ft)
% INPUT:
% xData - X target coordinates
% yData - Y target coordinates
% ErrorData - X or Y estimation error in the target coordinates 
% show_fig - flag to show the fit results
% ft - type of fitting: biharmonic (default), lowess, cubicintep
% OUTPUT:
% fitresult - fit object representing the surface
% gof - goodness of fit indexes


% Set up fittype and options.
if nargin<5
    ft = 'biharmonicinterp';
    % ft = 'lowess';
    % ft = 'cubicinterp';
end

if nargin < 4
    show_fig =false;
end

% Format Data
xData=xData(:);
yData=yData(:);
ErrorData=ErrorData(:);

% Fit model to data.
[fitresult, gof] = fit( [xData, yData], ErrorData, ft );

if show_fig
    % Plot fit with data.
    figure( 'Name', 'untitled fit 1' );
    h = plot( fitresult, [xData, yData], ErrorData );

    % Label axes
    xlabel( 'X position' );
    ylabel( 'Y position' );
    zlabel( 'Error' );
    grid on
    view( 124.5, 22.0 );
end

